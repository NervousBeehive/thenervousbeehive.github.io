import colorama
import random
from custom_libaries.aesthetics import seperator, clear_screen, point_bar
from custom_libaries.inputplus import validated_input_whitelist
from entity import Player, Enemy
from menus import controls_and_rules

def main_menu():
    # Initialize colorama so colors show up correctly in terminal
    colorama.init(convert=True)
    # Main Menu artwork
    seperator()
    print("          Dicejack Dungeon")
    seperator()
    print('''
                   (( _______      
         _______     /\O    O\     
        /O     /\   /  \      \    
       /   O  /O \ / O  \O____O\ ))
    ((/_____O/    \\    /O     /   
      \O    O\    / \  /   O  /    
       \O    O\ O/   \/_____O/     
        \O____O\/ ))          ))   
      ((                           
      ''')
    seperator()
    # Main Menu options
    print("1. New Game")
    print("2. Controls/Rules")
    print("3. Exit")
    seperator()
    # Player chooses what to do
    choice = validated_input_whitelist("> ", ["1", "2", "3"])
    if choice == "1":
        clear_screen()
        game()
    elif choice == "2":
        clear_screen()
        controls_and_rules()
    else:
        exit()

def game():
    # Create player
    seperator()
    player_name = input("What is your name adventurer? ")
    player = Player(player_name, 20, 20, 1, 21)
    # Create map
    possible_rooms = ["rat", "bat", "healing_spring", "chest"]
    weights = [0.6, 0.4, 0.1, 0.1]
    map_length = 9
    map = random.choices(possible_rooms, weights, k=map_length)
    # Make sure first room is enemy and last room is exit
    map[0] = "rat"
    map.append("exit")
    # Main game loop
    for room in map:
        seperator()
        # Depending on what room you walk into different events will be called
        if room == "rat":
            print("You walk into a dark room suddenly a large rat jumps at you!")
            input("You prepare to battle.")
            # Create new Enemy class and get it ready for combat
            rat = Enemy("Rat", 10, 10, 1, 18)
            start_combat(player, rat)
        elif room == "bat":
            print("You walk into a tall room suddenly a large bat swoops down towards you!")
            input("You prepare to battle.")
            # Create new Enemy class and get it ready for combat
            bat = Enemy("Bat", 5, 5, 3, 11)
            start_combat(player, bat)
        elif room == "healing_spring":
            seperator()
            print("You walk strange room. In front of you a water flows from a spring!")
            print("The spring feels magical somehow.")
            choice = validated_input_whitelist("Drink from the spring (yes/no): ", ["yes", "no"])
            if choice == "yes":
                print("The spring water tastes wonderful it seems to heal your wounds.")
                player.health += 5
                if player.health > player.max_health:
                    player.health = player.max_health
                input("HEALTH restored")
            clear_screen()
        elif room == "chest":
            seperator()
            print("You walk into a dark room. A chest lies on the floor in front of you")
            print("You open the chest. Inside lies a steel sword.")
            player.damage = 2
            input("As you wield the sword you feel your DAMAGE increase")
            clear_screen()
        else:
            # Win condition
            print("You stumble into a lit room. Realizing what this means you look up and ")
            print("see the exit in the ceiling. You climb out of the exit and rest on the grass")
            print("Congratulations on winning the game!")
            input("> ")
            clear_screen()
            main_menu()


def combat_screen(player, enemy):
    # Combat screen, it's a function so that it can be updated easier
    clear_screen()
    seperator()
    enemy_passed_text = ""
    if enemy.has_passed:
        enemy_passed_text = "PASSED"
    print(enemy.name + ": HEALTH = " + str(enemy.health) + "/" + str(enemy.max_health) + " DAMAGE = " + str(enemy.damage), enemy_passed_text)
    seperator()
    print(str(point_bar(enemy)) + " - " + enemy.name)
    print(str(point_bar(player)) + " - " + player.name)
    seperator()
    player_passed_text = ""
    if player.has_passed:
        player_passed_text = "PASSED"
    print(player.name + ": HEALTH = " + str(player.health) + "/" + str(player.max_health) + " DAMAGE = " + str(player.damage), player_passed_text)
    seperator()
    print("")

def start_combat(player, enemy):
    # Combat logic here
    combat_screen(player, enemy)
    while True:
        # Checking that neither enemy nor player are dead before playing
        if (player.health > 0) and (enemy.health > 0):
            if not player.has_passed:
                input(player.name + "'s turn.")
                combat_screen(player, enemy)
                choice = validated_input_whitelist("What would you like to do (roll/pass): ", ["roll", "pass"])
                combat_screen(player, enemy)
                if choice == "roll":
                    player.roll()
                    combat_screen(player, enemy)
                else:
                    player.pass_go()
                    combat_screen(player, enemy)
            if not enemy.has_passed:
                input(enemy.name + "'s turn.")
                combat_screen(player, enemy)
                choice = enemy.ai(player)
                input(enemy.name + " has chose to " + choice)
                combat_screen(player, enemy)
                if choice == "roll":
                    enemy.roll()
                    combat_screen(player, enemy)
                else:
                    enemy.pass_go()
                    combat_screen(player, enemy)
            if player.has_passed and enemy.has_passed:
                print(player.name + "'s final score equals " + str(player.points) + ".")
                print(enemy.name + "'s final score equals " + str(enemy.points) + ".")
                print("")
                if player.points > enemy.points:
                    print(player.name + " wins by " + str(player.points - enemy.points) + " points!")
                    print(player.name + " deals " + str(player.damage * (player.points - enemy.points)) + " to " + enemy.name)
                    enemy.health -= player.damage * (player.points - enemy.points)
                elif player.points < enemy.points:
                    print(enemy.name + " wins by " + str(enemy.points - player.points) + " points!")
                    print(enemy.name + " deals " + str(enemy.damage * (enemy.points - player.points)) + " to " + player.name)
                    player.health -= enemy.damage * (enemy.points - player.points)
                else:
                    print("Both " + player.name + " and " + enemy.name + " scored the same amount of points Draw!")
                # Reset both player and enemy
                player.has_passed = False
                enemy.has_passed = False
                player.points = 0
                enemy.points = 0

        # If either player or enemy are dead
        else:
            # If player is dead go back to main menu
            if player.health <= 0:
                input("You Died!")
                clear_screen()
                main_menu()
            # If the enemy dies tell the player and break loop so player can go to next room
            else:
                input("You defeated the " + enemy.name)
                break


main_menu()