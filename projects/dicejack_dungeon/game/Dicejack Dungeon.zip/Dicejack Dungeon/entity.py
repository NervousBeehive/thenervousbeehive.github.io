
import random
class Entity():
    def __init__(self, name, max_health, health, damage, max_points):
        self.name = name
        self.max_health = max_health
        self.health = health
        self.damage = damage
        self.max_points = max_points
    has_passed = False
    points = 0

    def pass_go(self):
        self.has_passed = True
        input(self.name + " has chose to pass.")

    def roll(self):
        random_number = random.randint(1, 10)
        input(self.name + " rolled a " + str(random_number))
        self.points += random_number
        if self.points > self.max_points:
            print(self.name + "'s points are greater than " + str(
                self.max_points) + ". Points set to half of max points.")
            input("Automatically passed " + self.name)
            self.points = int(self.max_points / 2)
            self.has_passed = True

class Player(Entity):
    pass

class Enemy(Entity):
    def ai(self, player):
        # Enemy AI
        # Deciding whether to pass or roll
        risk = 0
        safe = 0
        for i in range(1, 10):
            if self.points + i > 21:
                risk += 1
            else:
                safe += 1
        # If other player has passed and cpu's score is higher than other players cpu will also pass
        if player.has_passed and self.points > player.points:
            return "pass"
        # If the percentage is in enemies favour roll
        elif safe > risk:
            return "roll"
        else:
            return "pass"
