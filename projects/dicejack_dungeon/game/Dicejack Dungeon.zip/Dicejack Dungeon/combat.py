
def combat_screen(player, enemy):
    # Combat screen, it's a function so that it can be updated easier
    clear_screen()
    seperator()
    enemy_passed_text = ""
    if enemy.has_passed:
        enemy_passed_text = "PASSED"
    print(enemy.name + ": HEALTH = " + str(enemy.health) + "/" + str(enemy.max_health) + " DAMAGE = " + str(enemy.damage), enemy_passed_text)
    seperator()
    print(str(point_bar(enemy)) + " - " + enemy.name)
    print(str(point_bar(player)) + " - " + player.name)
    seperator()
    player_passed_text = ""
    if player.has_passed:
        player_passed_text = "PASSED"
    print(player.name + ": HEALTH = " + str(player.health) + "/" + str(player.max_health) + " DAMAGE = " + str(player.damage), player_passed_text)
    seperator()
    print("")

def start_combat(player, enemy):
    # Combat logic here
    combat_screen(player, enemy)
    while True:
        # Checking that neither enemy nor player are dead before playing
        if (player.health > 0) and (enemy.health > 0):
            if not player.has_passed:
                input(player.name + "'s turn.")
                combat_screen(player, enemy)
                choice = validated_input_whitelist("What would you like to do (roll/pass): ", ["roll", "pass"])
                combat_screen(player, enemy)
                if choice == "roll":
                    player.roll()
                    combat_screen(player, enemy)
                else:
                    player.pass_go()
                    combat_screen(player, enemy)
            if not enemy.has_passed:
                input(enemy.name + "'s turn.")
                combat_screen(player, enemy)
                choice = enemy.ai(player)
                input(enemy.name + " has chose to " + choice)
                combat_screen(player, enemy)
                if choice == "roll":
                    enemy.roll()
                    combat_screen(player, enemy)
                else:
                    enemy.pass_go()
                    combat_screen(player, enemy)
            if player.has_passed and enemy.has_passed:
                print(player.name + "'s final score equals " + str(player.points) + ".")
                print(enemy.name + "'s final score equals " + str(enemy.points) + ".")
                print("")
                if player.points > enemy.points:
                    print(player.name + " wins by " + str(player.points - enemy.points) + " points!")
                    print(player.name + " deals " + str(player.damage * (player.points - enemy.points)) + " to " + enemy.name)
                    enemy.health -= player.damage * (player.points - enemy.points)
                elif player.points < enemy.points:
                    print(enemy.name + " wins by " + str(enemy.points - player.points) + " points!")
                    print(enemy.name + " deals " + str(enemy.damage * (enemy.points - player.points)) + " to " + player.name)
                    player.health -= enemy.damage * (enemy.points - player.points)
                else:
                    print("Both " + player.name + " and " + enemy.name + " scored the same amount of points Draw!")
                # Reset both player and enemy
                player.has_passed = False
                enemy.has_passed = False
                player.points = 0
                enemy.points = 0

        # If either player or enemy are dead
        else:
            # If player is dead go back to main menu
            if player.health <= 0:
                input("You Died!")
                clear_screen()
                main_menu()
            # If the enemy dies tell the player and break loop so player can go to next room
            else:
                input("You defeated the " + enemy.name)
                break
