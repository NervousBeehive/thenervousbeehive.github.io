import random
import colorama
import os
from custom_libaries import inputplus

def calculate_winner(player1, player2):
    print(colorama.Fore.LIGHTWHITE_EX + player1.username + "'s final score equals " + str(player1.score) + ".")
    print("CPU's final score equals " + str(player2.score) + ".")
    print("")

    if player1.score > player2.score:
        print(player1.username + " wins by " + str(player1.score - player2.score) + " points!")
    elif player1.score < player2.score:
        print(player2.username + " wins by " + str(player2.score - player1.score) + " points!")
    else:
        print("Both " + player1.username + " and " + player2.username + " scored the same amount of points Draw!")

    print("------------------------------------")
    print("")
    play_again()

def play_again():
    # Asking player if they would like to play again
    choice = inputplus.validated_input_str("Would you like to play again (yes/no): ", ["yes", "no"])
    if choice == "yes":
        os.system("cls")
        intro()
    else:
        print("Thanks for playing. Goodbye!")
        exit()

class Player:
    # Initializing variables
    has_passed = False
    score = 0
    deck = []
    username = ""
    color = colorama.Fore.LIGHTWHITE_EX
    for i in range(10):
        deck.append(random.randint(1, 10))

    def roll(self):
        print("")
        # Picking random number to use as index based on the lenght of deck. Index starts a t 0 in lists therefore you must take one of the lenght
        random_index = random.randint(0, len(self.deck) - 1)
        random_number = self.deck[random_index]
        # pop() function removes number from deck after it has been rolled once
        self.deck.pop(random_index)
        print(self.username + " rolled a " + str(random_number) + ".")
        self.score += random_number
        # Making sure players score is not over 21 as that would cause them to lose
        if self.score > 21:
            print(self.username + "'s score is greater than 21. Score set to 0 and automatically passed.")
            print("------------------------------------")
            self.score = 0
            self.has_passed = True
        else:
            print(self.username + "'s new total is " + str(self.score) + ".")
            print(colorama.Fore.LIGHTWHITE_EX + "------------------------------------")

    def pass_go(self):
        # If player chooses to pass player_passed will be set to True, so they aren't asked if they would like to roll or pass again
        print(self.username + " has passed.")
        print(colorama.Fore.LIGHTWHITE_EX + "------------------------------------")
        self.has_passed = True

    def turn_opening_text(self):
        print(self.color + self.username + "'s turn!")
        print(self.username + " currently has " + str(self.score) + " score.")
        print(self.username + "'s current deck = " + str(self.deck))

class CPU(Player):
    def cpu_ai(self, other_player):
        # CPU AI
        # Firstly CPU checks all numbers in deck and sees if drawing them would put their score over 21
        # If the number will but them over 21, 1 is added to risk if it won't put them over 21 1 is added to safe
        risk = 0
        safe = 0
        for number in self.deck:
            if self.score + number > 21:
                risk += 1
            else:
                safe += 1
        # Deciding whether to pass or roll
        # If other player has passed and cpu's score is higher than other players cpu will also pass
        if other_player.has_passed and self.score > other_player.score:
            return "pass"
        # If the percentage of safe numbers that could be drawn is over 50% cpu will choose to roll
        elif safe > risk:
            return "roll"
        # And even if the percentage of risky numbers is more than safe numbers if the player has passed and has a higher score than the cpu,
        # the cpu will choose to roll anyway as it's better than just accepting defeat
        elif other_player.has_passed and self.score < other_player.score:
            return "roll"
        else:
            return "pass"

def intro():
    # Initialize colorama so colors show up correctly in terminal
    colorama.init(convert=True)

    # Intro to the game explaining rules and asking if the player would like to play singleplayer or multiplayer
    print("")
    print(colorama.Fore.LIGHTWHITE_EX + "------------------------------------")
    print("    Welcome to Blackjack Dice!")
    print('''
                   (( _______      
         _______     /\O    O\     
        /O     /\   /  \      \    
       /   O  /O \ / O  \O____O\ ))
    ((/_____O/    \\    /O     /   
      \O    O\    / \  /   O  /    
       \O    O\ O/   \/_____O/     
        \O____O\/ ))          ))   
      ((                           
      ''')
    print("------------------------------------")
    print("Rules:")
    print("1. Both players start with a deck of 10 cards with random values ranging from 1 - 10.")
    print("2. Both players take turns drawing cards trying to get as close to 21.")
    print("3. Although if you go over 21 you automatically lose and the other player wins.")
    print("4. However if both players pass and neither go over 21 whoever has the highest number wins.")
    print("------------------------------------")

    gamemode = inputplus.validated_input_str("What gamemode would you like to play ((s)ingleplayer/(m)ultiplayer/(sim)ulation): ",
                               ["s", "m", "sim"])
    if gamemode == "m":
        multiplayer()
    elif gamemode == "s":
        singleplayer()
    else:
        simulation()

def singleplayer():
    # Initialize both player and cpu
    player = Player()
    cpu = CPU()

    # Setting player and cpu names
    cpu.username = "CPU"
    player.username = input("Please enter your username: ")
    print("------------------------------------")

    # Setting player and cpu colors
    cpu.color = colorama.Fore.LIGHTBLUE_EX
    player.color = colorama.Fore.LIGHTGREEN_EX

    # Main game loop
    while True:
        # Checking if Player 1 hasn't passed before asking if they would like to roll or pass
        if not player.has_passed:
            player.turn_opening_text()
            choice = inputplus.validated_input_str("What would you like to do (roll/pass): ", ["roll", "pass"])
            if choice == "roll":
                player.roll()
            else:
                player.pass_go()

        # Checking if Player 1 hasn't passed before asking if they would like to roll or pass
        if not cpu.has_passed:
            cpu.turn_opening_text()
            choice = cpu.cpu_ai(player)
            print(cpu.username + " has chose to " + choice)
            print("")
            if choice == "roll":
                cpu.roll()
            else:
                cpu.pass_go()

        # Once both player and cpu have passed display both players scores before calculating who wins
        elif player.has_passed and cpu.has_passed:
            calculate_winner(player, cpu)

def multiplayer():
    choice = inputplus.validated_input_natural_num("How many players are playing (1-4): ", 4)
    player_names = []
    for i in range(choice):
        player_names.append(input("Please enter Player " + str(i + 1) + "'s username: "))
    colors = [colorama.Fore.LIGHTGREEN_EX, colorama.Fore.LIGHTBLUE_EX, colorama.Fore.LIGHTRED_EX, colorama.Fore.LIGHTYELLOW_EX, colorama.Fore.LIGHTMAGENTA_EX, colorama.Fore.LIGHTCYAN_EX]

    players = []
    for name in player_names:
        new_player = Player()
        new_player.username = name
        new_player.color = random.choice(colors)
        players.append(new_player)

    while True:
        for player in players:
            if not player.has_passed:
                player.turn_opening_text()
                choice = inputplus.validated_input_str("What would you like to do (roll/pass): ", ["roll", "pass"])
                if choice == "roll":
                    player.roll()
                else:
                    player.pass_go()

        passed = 0
        for player in players:
            if player.has_passed:
                passed += 1
        if passed == len(players):
            winner = ""
            top_score = 0
            for player in players:
                if player.score > top_score:
                    top_score = player.score
                    winner = player.username
            for player in players:
                print(player.username + " final score equals " + str(player.score))
            print("Winner is " + winner)
            break

def simulation():
    # Initialize both cpus
    cpu1 = CPU()
    cpu2 = CPU()

    # Setting cpu names
    cpu1.username = "CPU 1"
    cpu2.username = "CPU 2"
    print("------------------------------------")

    # Setting player and cpu colors
    cpu1.color = colorama.Fore.LIGHTBLUE_EX
    cpu2.color = colorama.Fore.LIGHTGREEN_EX

    # Main game loop
    while True:
        if not cpu1.has_passed:
            cpu1.turn_opening_text()
            choice = cpu1.cpu_ai(cpu2)
            print(cpu1.username + " has chose to " + choice)
            print("")
            if choice == "roll":
                cpu1.roll()
            else:
                cpu1.pass_go()

        if not cpu2.has_passed:
            cpu2.turn_opening_text()
            choice = cpu2.cpu_ai(cpu1)
            print(cpu2.username + " has chose to " + choice)
            print("")
            if choice == "roll":
                cpu2.roll()
            else:
                cpu2.pass_go()

        # Once both cpus have passed display both players scores before calculating who wins
        elif cpu1.has_passed and cpu2.has_passed:
            calculate_winner(cpu1, cpu2)

intro()
