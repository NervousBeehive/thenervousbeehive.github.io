
def validated_input_whitelist(question, whitelist):
    # Glorified input function that checks input against a list only allowing whitelisted inputs to be accepted
    answer = input(question)
    while True:
        if answer in whitelist:
            return answer
        else:
            print("Incorrect input please try again!")
            answer = input(question)

def validated_input_natural_num(question, max_number):
    # Input function that makes sure input is integer
    answer = int(input(question))
    while True:
        if answer > 0 and answer <= max_number:
            return answer
        else:
            print("Incorrect input please try again!")
            answer = input(question)