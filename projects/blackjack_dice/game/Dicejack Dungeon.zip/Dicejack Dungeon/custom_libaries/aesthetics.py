import os

def seperator():
    print("X----------------------------------X")

def clear_screen():
    os.system("cls")

def point_bar(entity):
    # Function that can return a bar based on an entities points and max points
    bar = []
    for i in range(entity.max_points):
        bar.append("□")
    for i in range(entity.points):
        bar[i] = "■"
    return "".join(bar)
