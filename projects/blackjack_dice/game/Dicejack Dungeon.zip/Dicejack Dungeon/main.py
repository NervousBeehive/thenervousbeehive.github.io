
import random
from custom_libaries.aesthetics import seperator, clear_screen, point_bar
from custom_libaries.inputplus import validated_input_whitelist
from entity import Player, Enemy
from menus import main_menu
from combat import combat

def game():
    # Create player
    seperator()
    player_name = input("What is your name adventurer? ")
    player = Player(player_name, 20, 20, 1, 21)
    # Create map
    possible_rooms = ["rat", "bat", "healing_spring", "chest"]
    weights = [0.6, 0.4, 0.1, 0.1]
    map_length = 9
    map = random.choices(possible_rooms, weights, k=map_length)
    # Make sure first room is enemy and last room is exit
    map[0] = "rat"
    map.append("exit")
    # Main game loop
    for room in map:
        seperator()
        # Depending on what room you walk into different events will be called
        if room == "rat":
            print("You walk into a dark room suddenly a large rat jumps at you!")
            input("You prepare to battle.")
            # Create new Enemy class and get it ready for combat
            rat = Enemy("Rat", 10, 10, 1, 18)
            combat(player, rat)
        elif room == "bat":
            print("You walk into a tall room suddenly a large bat swoops down towards you!")
            input("You prepare to battle.")
            # Create new Enemy class and get it ready for combat
            bat = Enemy("Bat", 5, 5, 3, 11)
            combat(player, bat)
        elif room == "healing_spring":
            seperator()
            print("You walk strange room. In front of you a water flows from a spring!")
            print("The spring feels magical somehow.")
            choice = validated_input_whitelist("Drink from the spring (yes/no): ", ["yes", "no"])
            if choice == "yes":
                print("The spring water tastes wonderful it seems to heal your wounds.")
                player.health += 5
                if player.health > player.max_health:
                    player.health = player.max_health
                input("HEALTH restored")
            clear_screen()
        elif room == "chest":
            seperator()
            print("You walk into a dark room. A chest lies on the floor in front of you")
            print("You open the chest. Inside lies a steel sword.")
            player.damage = 2
            input("As you wield the sword you feel your DAMAGE increase")
            clear_screen()
        else:
            # Win condition
            print("You stumble into a lit room. Realizing what this means you look up and ")
            print("see the exit in the ceiling. You climb out of the exit and rest on the grass")
            print("Congratulations on winning the game!")
            input("> ")
            clear_screen()
            main_menu()


main_menu()