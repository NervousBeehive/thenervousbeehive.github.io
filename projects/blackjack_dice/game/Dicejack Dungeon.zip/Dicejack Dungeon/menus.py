
import colorama
from custom_libaries.aesthetics import seperator, clear_screen
from custom_libaries.inputplus import validated_input_whitelist
def main_menu():
    # Initialize colorama so colors show up correctly in terminal
    colorama.init(convert=True)
    # Main Menu artwork
    seperator()
    print("          Dicejack Dungeon")
    seperator()
    print('''
                   (( _______      
         _______     /\O    O\     
        /O     /\   /  \      \    
       /   O  /O \ / O  \O____O\ ))
    ((/_____O/    \\    /O     /   
      \O    O\    / \  /   O  /    
       \O    O\ O/   \/_____O/     
        \O____O\/ ))          ))   
      ((                           
      ''')
    seperator()
    # Main Menu options
    print("1. New Game")
    print("2. Controls/Rules")
    print("3. Exit")
    seperator()
    # Player chooses what to do
    choice = validated_input_whitelist("> ", ["1", "2", "3"])
    if choice == "1":
        clear_screen()
        game()
    elif choice == "2":
        clear_screen()
        controls_and_rules()
    else:
        exit()

def controls_and_rules():
    seperator()
    print("          Controls/Rules")
    seperator()
    print("Dicejack Dungeons is a roguelike dungeon crawler mixed with the card game Blackjack.")
    print("Players traverse through a randomly generated dungeon trying to reach the exit.")
    print("However instead of the traditional method of combat players must duel their enemies in rounds of a modified Blackjack.")
    print("")
    print("Combat Rules:")
    print("Both player and enemy must try and reduce their opponents health bar to zero. If the enemy kills the player it is game over")
    print("however if the player kills the enemy they will be rewarded with gold, items and crafting materials before moving to the next room")
    print("of the dungeon. Combat consists of both opponents rolling dice trying to get as close to the number 12 while also not going")
    print("over 12. Each turn the Player will be given the choice to either roll or pass. Once either both opponents have passed or one goes over")
    print("12 the winner will deal damage to their opponent based on how much they won by.If either opponent manages to score a perfect 12 they")
    print("will perform a critical strike dealing double damage. If both opponents tie nothing happens. Final damage is determined by opponents damage")
    print("minus other opponents shield.")
    print("")
    print("Exploration Rules:")
    print("While you traverse the dungeon you will encounter many rooms e.g. monster room, chest room, shop room, trap room, crafting room.")
    seperator()
    print("1. Main Menu")
    choice = validated_input_whitelist("> ", ["1"])
    if choice == "1":
        clear_screen()
        main_menu()